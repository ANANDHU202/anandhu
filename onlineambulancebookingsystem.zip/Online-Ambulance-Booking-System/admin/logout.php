<?php
session_start();
$loc='location:login.php';
if(isset($_SESSION['driverid']))
{
    $loc='location:driver_login.php';
}

session_unset();
session_destroy();
header($loc);

?>